"""
view_config.py — Amazon Connect View: merged CONSENT + IDENTIFICATION.
──────────────────────────────────────────────────────────────────────
Single pre-chat View that collects data consent AND identity info in
one step.  The customer sees:

  1. "Data Consent & Identification" header
  2. Description: consent language about data use
  3. First Name, Middle Initial, Last Name, Phone, Email
  4. "I Consent & Start Chat" button (ConnectAction → StartChatContact)

View ID:   0b286577-6474-4a95-abc9-6fef67e1521c
View Name: CONSENT_AND_IDENTIFICATION
SHA256:    c9f91c9e6989be67db93067367383e8749d1799dc1857a514fa27a40fee030d2

To update: edit the View in Amazon Connect console, re-publish,
re-copy the widget snippet into widget_snippet.js, re-deploy.
"""

VIEW_CONFIG_JSON = (
    '{"arn":"arn:aws:connect:us-west-2:551642657889:instance/e75a053a-60c7-45f3-83f7'
    '-a24df6d3b52d/view/0b286577-6474-4a95-abc9-6fef67e1521c:$LATEST",'
    '"id":"0b286577-6474-4a95-abc9-6fef67e1521c",'
    '"content":{"actions":["ActionSelected"],'
    '"inputSchema":{"type":"object","properties":{},"required":[],'
    '"$defs":{"ViewCondition":{"$id":"/view/condition","type":"object",'
    '"patternProperties":{"^(MoreThan|LessThan|NotEquals|Equals|Includes)$":'
    '{"type":"object","properties":{"ElementByKey":{"type":"string"},'
    '"ElementByValue":{"anyOf":[{"type":"number"},{"type":"string"},'
    '{"type":"boolean"},{"type":"array"},{"type":"object"}]}},'
    '"additionalProperties":false},'
    '"^(AndConditions|OrConditions)$":{"type":"array",'
    '"items":{"$ref":"/view/condition"}}},"additionalProperties":false}}},'
    '"template":{"Head":{"Configuration":{"Layout":{"Columns":[12]}},'
    '"Integrations":[],"Title":"CONSENT_AND_IDENTIFICATION"},'
    '"Body":[{"_id":"Address_1770339674464","Type":"Container","Props":{},'
    '"Content":[{"_id":"Form_1770339805953","Type":"Form",'
    '"Props":{"HideBorder":false},"Content":'
    '[{"_id":"Header_1770340308206","Type":"Header",'
    '"Props":{"variant":"h2","description":"By submitting this form you consent '
    'to the use of your data for identification purposes and to research resources '
    'based on your needs. All information is kept confidential."},'
    '"Content":["Data Consent & Identification"]},'
    '{"_id":"FirstName_1770340124686","Type":"FormInput",'
    '"Props":{"Label":"First Name","Name":"first-name","InputType":"text"},"Content":[]},'
    '{"_id":"FirstName_1770339805953","Type":"FormInput",'
    '"Props":{"Label":"Middle Initial","Name":"middle-name","InputType":"text","Required":false},"Content":[]},'
    '{"_id":"LastName_1770339805953","Type":"FormInput",'
    '"Props":{"Label":"Last Name","Name":"last-name","InputType":"text"},"Content":[]},'
    '{"_id":"StreetAddress_1770339674464","Type":"FormInput",'
    '"Props":{"Label":"Phone Number","Name":"phone-number","InputType":"tel","Required":false},"Content":[]},'
    '{"_id":"FirstName_1770340552258","Type":"FormInput",'
    '"Props":{"Label":"Email","Name":"email","InputType":"email"},"Content":[]},'
    '{"_id":"ConnectAction_1770351336556","Type":"ConnectAction",'
    '"Props":{"ConnectActionType":"StartChatContact","Label":"I Consent & Start Chat",'
    '"StartTaskContactProps":{"ContactFlowId":"","TaskFields":{"Name":"","References":{}},'
    '"Attributes":[{"Key":"","Value":""}]},'
    '"StartEmailContactProps":{"DestinationEmailAddress":"","ContactFlowId":"",'
    '"EmailFields":{"CustomerDisplayName":"","CustomerEmailAddress":"","Subject":"","Body":""},'
    '"Attributes":[{"Key":"","Value":""}]},'
    '"StartChatContactProps":{"ContactFlowId":"",'
    '"ChatFields":{"CustomerDisplayName":"","InitialMessage":""},'
    '"Attributes":[{"Key":"","Value":""}]}},'
    '"Content":["Connect Action Button"]}]}],'
    '"Configuration":{"Layout":{"Columns":"12"}}}]}},'
    '"name":"CONSENT_AND_IDENTIFICATION","status":"PUBLISHED",'
    '"type":"CUSTOMER_MANAGED",'
    '"viewContentSha256":"c9f91c9e6989be67db93067367383e8749d1799dc1857a514fa27a40fee030d2"}'
)
